import React, { useState, useEffect, useId } from 'react';
import { SFXEvent, EventStatus } from '../types';
import { 
  getEventsFromStorage, 
  addOrUpdateEvent, 
  deleteEventFromStorage, 
  searchEvents, 
  resetToDemoData 
} from '../services/storage';
import { 
  Phone, 
  MessageSquare, 
  Receipt, 
  Trash2, 
  Edit3, 
  Calendar as CalendarIcon, 
  Search, 
  RotateCcw, 
  Plus, 
  Check, 
  Sparkles,
  Smartphone
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AndroidEmulatorProps {
  onOpenSlip: (event: SFXEvent) => void;
}

const STATUSES: EventStatus[] = ['Booked', 'Advance Pending', 'Confirmed', 'Completed', 'Cancelled'];

export const AndroidEmulator: React.FC<AndroidEmulatorProps> = ({ onOpenSlip }) => {
  const [events, setEvents] = useState<SFXEvent[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Form fields
  const [customer, setCustomer] = useState('');
  const [type, setType] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [venue, setVenue] = useState('');
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState('');
  const [status, setStatus] = useState<EventStatus>('Booked');
  const [notes, setNotes] = useState('');
  const [editingId, setEditingId] = useState<number>(-1);
  const [customerError, setCustomerError] = useState('');

  // Toast & Android Dialog simulation
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [deleteDialogEvent, setDeleteDialogEvent] = useState<SFXEvent | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);

  const customerInputId = useId();
  const typeInputId = useId();
  const venueInputId = useId();
  const phoneInputId = useId();
  const amountInputId = useId();
  const statusSelectId = useId();
  const notesInputId = useId();
  const searchInputId = useId();

  useEffect(() => {
    refreshList(searchQuery);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => prev === msg ? null : prev);
    }, 2800);
  };

  const refreshList = (query: string) => {
    const results = searchEvents(query);
    setEvents(results);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    refreshList(val);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer.trim()) {
      setCustomerError('Customer name is required');
      showToast('Customer name is required');
      return;
    }
    setCustomerError('');

    if (!eventDate) {
      showToast('Please choose an event date');
      return;
    }

    addOrUpdateEvent(
      {
        customer: customer.trim(),
        type: type.trim(),
        event_date: eventDate,
        venue: venue.trim(),
        phone: phone.trim(),
        amount: amount.trim(),
        status,
        notes: notes.trim(),
      },
      editingId === -1 ? undefined : editingId
    );

    const isNew = editingId === -1;
    showToast(isNew ? 'Event saved' : 'Event updated');

    if (isNew) {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.6 }
      });
    }

    handleClearForm();
    refreshList(searchQuery);
  };

  const handleClearForm = () => {
    setEditingId(-1);
    setCustomer('');
    setType('');
    setVenue('');
    setPhone('');
    setAmount('');
    setNotes('');
    setStatus('Booked');
    setEventDate('');
    setCustomerError('');
  };

  const handleLoadEventForEdit = (ev: SFXEvent) => {
    setEditingId(ev.id);
    setCustomer(ev.customer);
    setType(ev.type || '');
    setEventDate(ev.event_date);
    setVenue(ev.venue || '');
    setPhone(ev.phone || '');
    setAmount(ev.amount || '');
    setNotes(ev.notes || '');
    setStatus(ev.status || 'Booked');
    setCustomerError('');
    showToast('Event loaded for editing');

    // Scroll smoothly to form
    const formElem = document.getElementById('sfx-android-form');
    if (formElem) {
      formElem.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const confirmDelete = () => {
    if (!deleteDialogEvent) return;
    deleteEventFromStorage(deleteDialogEvent.id);
    showToast('Event deleted');
    setDeleteDialogEvent(null);
    if (editingId === deleteDialogEvent.id) {
      handleClearForm();
    }
    refreshList(searchQuery);
  };

  const handleQuickWhatsApp = (ev: SFXEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    const cleanPhone = (ev.phone || '').replace(/[^0-9]/g, '');
    const msg = `Hi ${ev.customer}, this is HI-TECH SFX regarding your event "${ev.type || 'Show'}" scheduled on ${ev.event_date}. Total: ₹${ev.amount || '0'}, Status: ${ev.status}.`;
    const url = cleanPhone ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleQuickCall = (ev: SFXEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    const cleanPhone = (ev.phone || '').replace(/[^0-9+]/g, '');
    if (cleanPhone) {
      window.location.href = `tel:${cleanPhone}`;
    } else {
      showToast('No valid phone number entered');
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto bg-slate-900 rounded-[36px] p-3 shadow-2xl border-4 border-slate-700/80 transition-all">
      {/* Android Device Bezel & Status Bar */}
      <div className="relative bg-[#f5f7fb] rounded-[28px] overflow-hidden min-h-[720px] flex flex-col text-slate-800">
        
        {/* Android Native Status Bar */}
        <div className="bg-[#0f4c81] text-white px-5 py-1.5 text-[11px] flex items-center justify-between font-mono font-medium select-none">
          <div className="flex items-center gap-1.5">
            <span>9:41</span>
            <span className="opacity-70 text-[10px]">AM</span>
          </div>
          <div className="flex items-center gap-2 text-[10px]">
            <span>4G • LTE</span>
            <span>100%</span>
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400"></div>
          </div>
        </div>

        {/* Header (Exact representation from MainActivity.java) */}
        <div className="bg-[#f5f7fb] px-4 pt-4 pb-2 border-b border-slate-200/60">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[#0f4c81] flex items-center justify-center text-white shadow-md shadow-blue-900/20">
                <Sparkles className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h1 className="text-[23px] font-black tracking-tight text-[#0f4c81] leading-none">
                  HI-TECH SFX
                </h1>
                <h2 className="text-[15px] font-bold text-slate-800 leading-tight mt-0.5">
                  Event Date & Data Manager
                </h2>
              </div>
            </div>
            <button
              onClick={() => {
                resetToDemoData();
                refreshList(searchQuery);
                showToast('Reset to demo events');
              }}
              className="p-1.5 text-xs text-slate-500 hover:text-[#0f4c81] rounded-lg hover:bg-slate-200/60 transition"
              title="Reload sample data"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[12px] text-slate-500 mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
            Offline event records • Stored on this phone
          </p>
        </div>

        {/* Scrollable Root Container (MainActivity.java ScrollView) */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          
          {/* Add / Edit Event Form Card (Exact LinearLayout form from Java) */}
          <form 
            id="sfx-android-form"
            onSubmit={handleSave} 
            className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200/70 space-y-3"
          >
            <div className="flex items-center justify-between pb-1 border-b border-slate-100">
              <span className="text-[16px] font-bold text-slate-900 flex items-center gap-2">
                {editingId === -1 ? (
                  <>
                    <Plus className="w-4 h-4 text-[#0f4c81]" /> Add Event
                  </>
                ) : (
                  <>
                    <Edit3 className="w-4 h-4 text-amber-600" /> Edit Event (#{editingId})
                  </>
                )}
              </span>
              {editingId !== -1 && (
                <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                  Editing Mode
                </span>
              )}
            </div>

            {/* Customer field */}
            <div>
              <label htmlFor={customerInputId} className="block text-[12px] font-bold text-slate-700 mb-1">Customer *</label>
              <input
                id={customerInputId}
                type="text"
                placeholder="Customer / company name"
                value={customer}
                onChange={e => {
                  setCustomer(e.target.value);
                  if (customerError) setCustomerError('');
                }}
                className={`w-full px-3 py-2 text-[14px] rounded-lg border ${
                  customerError ? 'border-red-500 bg-red-50/30' : 'border-slate-300'
                } focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent transition`}
              />
              {customerError && (
                <span className="text-[11px] text-red-600 font-medium mt-0.5 block">{customerError}</span>
              )}
            </div>

            {/* Event Type field */}
            <div>
              <label htmlFor={typeInputId} className="block text-[12px] font-bold text-slate-700 mb-1">Event type</label>
              <input
                id={typeInputId}
                type="text"
                placeholder="Event type (wedding, corporate, etc.)"
                value={type}
                onChange={e => setType(e.target.value)}
                className="w-full px-3 py-2 text-[14px] rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent transition"
              />
            </div>

            {/* Event Date Picker Button (MainActivity.java chooseDate) */}
            <div>
              <label className="block text-[12px] font-bold text-slate-700 mb-1">Event date *</label>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowDatePicker(!showDatePicker)}
                  className="w-full px-3 py-2.5 text-[14px] font-bold text-left rounded-lg bg-[#e8f0fa] text-[#0f4c81] hover:bg-[#d8e7f8] flex items-center justify-between transition cursor-pointer border border-[#c4dcfa]"
                >
                  <span className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-[#0f4c81]" />
                    {eventDate ? `Event date: ${eventDate}` : 'Choose event date  ▾'}
                  </span>
                  <span className="text-xs text-sky-700 font-normal">Change</span>
                </button>

                {showDatePicker && (
                  <div className="mt-2 p-3 bg-white border border-slate-200 rounded-xl shadow-lg">
                    <div className="text-xs font-semibold text-slate-500 mb-2">Select Date:</div>
                    <input
                      type="date"
                      value={eventDate}
                      onChange={e => {
                        setEventDate(e.target.value);
                        setShowDatePicker(false);
                      }}
                      className="w-full px-3 py-2 border rounded-lg text-sm font-mono text-slate-800"
                    />
                    <div className="flex gap-2 mt-2">
                      <button
                        type="button"
                        onClick={() => {
                          const today = new Date().toISOString().split('T')[0];
                          setEventDate(today);
                          setShowDatePicker(false);
                        }}
                        className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md text-slate-700 font-medium"
                      >
                        Today
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
                          setEventDate(tomorrow);
                          setShowDatePicker(false);
                        }}
                        className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md text-slate-700 font-medium"
                      >
                        Tomorrow
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Venue field */}
            <div>
              <label htmlFor={venueInputId} className="block text-[12px] font-bold text-slate-700 mb-1">Venue</label>
              <input
                id={venueInputId}
                type="text"
                placeholder="Venue / address"
                value={venue}
                onChange={e => setVenue(e.target.value)}
                className="w-full px-3 py-2 text-[14px] rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent transition"
              />
            </div>

            {/* Phone & Amount in Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor={phoneInputId} className="block text-[12px] font-bold text-slate-700 mb-1">Phone</label>
                <input
                  id={phoneInputId}
                  type="tel"
                  placeholder="Contact number"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3 py-2 text-[14px] rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent transition"
                />
              </div>

              <div>
                <label htmlFor={amountInputId} className="block text-[12px] font-bold text-slate-700 mb-1">Amount (₹)</label>
                <input
                  id={amountInputId}
                  type="number"
                  placeholder="Total amount (₹)"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  className="w-full px-3 py-2 text-[14px] rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent transition font-mono"
                />
              </div>
            </div>

            {/* Status Spinner */}
            <div>
              <label htmlFor={statusSelectId} className="block text-[12px] font-bold text-slate-700 mb-1">Status</label>
              <select
                id={statusSelectId}
                value={status}
                onChange={e => setStatus(e.target.value as EventStatus)}
                className="w-full px-3 py-2 text-[14px] rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent font-medium"
              >
                {STATUSES.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Notes field */}
            <div>
              <label htmlFor={notesInputId} className="block text-[12px] font-bold text-slate-700 mb-1">Notes</label>
              <textarea
                id={notesInputId}
                rows={2}
                placeholder="Notes, equipment, crew or payment details"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-3 py-2 text-[14px] rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent transition"
              />
            </div>

            {/* Action Buttons: Save Event & Clear Form */}
            <div className="pt-2 flex flex-col gap-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-[#0f4c81] hover:bg-[#0c3c66] text-white font-bold rounded-xl shadow-md text-[15px] flex items-center justify-center gap-2 transition active:scale-[0.98] cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{editingId === -1 ? 'Save Event' : 'Update Event'}</span>
              </button>

              <button
                type="button"
                onClick={handleClearForm}
                className="w-full py-2 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-[14px] transition active:scale-[0.98] cursor-pointer"
              >
                Clear Form
              </button>
            </div>
          </form>

          {/* Events Summary & Search Bar */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-extrabold text-slate-900 tracking-tight">
                Events ({events.length})
              </h3>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Sorted by Date ASC
              </span>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <label htmlFor={searchInputId} className="sr-only">Search events</label>
              <input
                id={searchInputId}
                type="text"
                placeholder="Search customer, event, venue, phone..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full pl-9 pr-3 py-2 text-[13px] bg-white rounded-xl border border-slate-300/80 focus:outline-none focus:ring-2 focus:ring-[#0f4c81] focus:border-transparent"
              />
              {searchQuery && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    refreshList('');
                  }}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 font-bold"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Event List (Exact card format from MainActivity.java) */}
          <div className="space-y-2.5 pb-6">
            {events.length === 0 ? (
              <div className="bg-white rounded-2xl p-6 text-center text-slate-500 text-[14px] border border-dashed border-slate-300">
                <p>No events found matching your search.</p>
                <p className="text-xs text-slate-400 mt-1">Add your first event above or clear search.</p>
              </div>
            ) : (
              events.map(ev => {
                const isSelectedForEdit = editingId === ev.id;
                return (
                  <div
                    key={ev.id}
                    onClick={() => handleLoadEventForEdit(ev)}
                    onContextMenu={e => {
                      e.preventDefault();
                      setDeleteDialogEvent(ev);
                    }}
                    className={`bg-white rounded-2xl p-4 shadow-sm border transition-all cursor-pointer relative ${
                      isSelectedForEdit 
                        ? 'border-[#0f4c81] ring-2 ring-[#0f4c81]/20 bg-blue-50/10' 
                        : 'border-slate-200/80 hover:border-slate-300 hover:shadow-md'
                    }`}
                  >
                    {/* Customer Heading */}
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-[17px] font-black text-[#0f4c81] tracking-tight leading-snug">
                        {ev.customer}
                      </h4>
                      <span className={`shrink-0 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        ev.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' :
                        ev.status === 'Completed' ? 'bg-blue-100 text-blue-800' :
                        ev.status === 'Advance Pending' ? 'bg-amber-100 text-amber-800' :
                        ev.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {ev.status}
                      </span>
                    </div>

                    {/* Date and Type */}
                    <div className="text-[13px] font-bold text-slate-700 mt-1 flex items-center gap-2">
                      <span className="font-mono text-[#0f4c81]">{ev.event_date}</span>
                      <span className="text-slate-300">•</span>
                      <span>{ev.type || 'Event'}</span>
                    </div>

                    {/* Venue */}
                    {ev.venue && (
                      <p className="text-[13px] text-slate-600 mt-1">
                        <strong className="text-slate-700 font-semibold">Venue:</strong> {ev.venue}
                      </p>
                    )}

                    {/* Phone */}
                    {ev.phone && (
                      <p className="text-[13px] text-slate-600 mt-0.5">
                        <strong className="text-slate-700 font-semibold">Phone:</strong> {ev.phone}
                      </p>
                    )}

                    {/* Amount */}
                    {ev.amount && (
                      <p className="text-[13px] text-emerald-800 font-bold mt-0.5">
                        Amount: ₹{Number(ev.amount).toLocaleString('en-IN')}
                      </p>
                    )}

                    {/* Notes */}
                    {ev.notes && (
                      <p className="text-[12px] text-slate-500 mt-1 bg-slate-50 p-2 rounded-lg border border-slate-100 line-clamp-2">
                        <strong className="text-slate-700">Notes:</strong> {ev.notes}
                      </p>
                    )}

                    {/* Quick action bar */}
                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">
                        Tap to edit • Right-click/long press to delete
                      </span>
                      <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
                        {ev.phone && (
                          <>
                            <button
                              onClick={e => handleQuickCall(ev, e)}
                              className="p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 hover:text-[#0f4c81] transition"
                              title="Call Customer"
                            >
                              <Phone className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={e => handleQuickWhatsApp(ev, e)}
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 transition"
                              title="Send WhatsApp Message"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            onOpenSlip(ev);
                          }}
                          className="p-1.5 rounded-lg text-[#0f4c81] hover:bg-blue-50 transition"
                          title="Generate Booking Voucher Slip"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            setDeleteDialogEvent(ev);
                          }}
                          className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition"
                          title="Delete Event"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}

            <p className="text-[11px] text-slate-400 text-center pt-1 pb-4">
              Tip: tap an event to edit it. Long-press an event to delete it.
            </p>
          </div>
        </div>

        {/* Android Navigation Bar */}
        <div className="bg-slate-900 text-white/50 py-2 flex items-center justify-around text-xs">
          <div className="w-4 h-4 border-l-2 border-b-2 border-white/50 rotate-45 transform"></div>
          <div className="w-3.5 h-3.5 rounded-full border-2 border-white/50"></div>
          <div className="w-3.5 h-3.5 border-2 border-white/50 rounded-xs"></div>
        </div>

        {/* Android Toast Notification Simulation */}
        {toastMessage && (
          <div className="absolute bottom-14 left-1/2 -translate-x-1/2 z-50 bg-slate-800/90 text-white text-[12px] font-medium px-4 py-2 rounded-full shadow-lg backdrop-blur-xs animate-in fade-in slide-in-from-bottom-2 duration-150">
            {toastMessage}
          </div>
        )}

        {/* Android AlertDialog (Exact representation from MainActivity.java) */}
        {deleteDialogEvent && (
          <div className="absolute inset-0 z-50 bg-black/60 flex items-center justify-center p-6 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl">
              <h3 className="text-[18px] font-bold text-slate-900">Delete event?</h3>
              <p className="text-[13px] text-slate-600 mt-2">
                Delete event for <strong>{deleteDialogEvent.customer}</strong> on <strong>{deleteDialogEvent.event_date}</strong>? This cannot be undone.
              </p>
              <div className="mt-6 flex justify-end gap-3">
                <button
                  onClick={() => setDeleteDialogEvent(null)}
                  className="px-4 py-2 text-[13px] font-bold text-slate-600 hover:bg-slate-100 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-4 py-2 text-[13px] font-bold text-red-600 hover:bg-red-50 rounded-lg transition"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
