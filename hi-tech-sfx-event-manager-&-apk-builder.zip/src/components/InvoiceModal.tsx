import React from 'react';
import { SFXEvent } from '../types';
import { X, Printer, Share2, Sparkles, Phone, MapPin, Calendar, CheckCircle } from 'lucide-react';

interface InvoiceModalProps {
  event: SFXEvent | null;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ event, onClose }) => {
  if (!event) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppShare = () => {
    const text = `*HI-TECH SFX - EVENT BOOKING SLIP*\n\n` +
      `*Client:* ${event.customer}\n` +
      `*Event Type:* ${event.type || 'Special Event'}\n` +
      `*Date:* ${event.event_date}\n` +
      `*Venue:* ${event.venue || 'Not specified'}\n` +
      `*Status:* ${event.status}\n` +
      `*Total Amount:* ₹${event.amount || '0'}\n` +
      `*Details:* ${event.notes || 'None'}\n\n` +
      `_HI-TECH SFX • Stage Effects & Pyro Solutions_`;

    const cleanPhone = (event.phone || '').replace(/[^0-9]/g, '');
    const url = cleanPhone.length >= 10 
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-lg rounded-2xl bg-white shadow-2xl overflow-hidden animate-in fade-in duration-200">
        {/* Header bar */}
        <div className="bg-[#0f4c81] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg tracking-wide">HI-TECH SFX</h3>
              <p className="text-xs text-sky-200">Official Event Booking Voucher</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center hover:bg-white/20 transition cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Slip Content */}
        <div className="p-6 space-y-5 print:p-0">
          <div className="flex justify-between items-start pb-4 border-b border-slate-100">
            <div>
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Booking ID</div>
              <div className="font-mono text-sm font-bold text-slate-800">#SFX-{String(event.id).padStart(5, '0')}</div>
            </div>
            <div className="text-right">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Status</div>
              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                event.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' :
                event.status === 'Completed' ? 'bg-blue-100 text-blue-800' :
                event.status === 'Advance Pending' ? 'bg-amber-100 text-amber-800' :
                event.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                'bg-slate-100 text-slate-700'
              }`}>
                <CheckCircle className="w-3 h-3" />
                {event.status}
              </span>
            </div>
          </div>

          {/* Customer & Event Details */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl">
            <div>
              <span className="text-xs text-slate-500 font-medium">Customer / Client</span>
              <p className="font-bold text-slate-900 text-base">{event.customer}</p>
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium">Event Type</span>
              <p className="font-semibold text-slate-800 text-sm">{event.type || 'Event'}</p>
            </div>

            <div>
              <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                <Calendar className="w-3 h-3 text-[#0f4c81]" /> Event Date
              </span>
              <p className="font-bold text-[#0f4c81] text-sm">{event.event_date}</p>
            </div>
            <div>
              <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                <Phone className="w-3 h-3 text-slate-400" /> Contact
              </span>
              <p className="font-semibold text-slate-800 text-sm">{event.phone || 'N/A'}</p>
            </div>
          </div>

          {/* Venue */}
          {event.venue && (
            <div className="text-xs text-slate-700 bg-blue-50/50 p-3 rounded-lg border border-blue-100/50 flex items-start gap-2">
              <MapPin className="w-4 h-4 text-[#0f4c81] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-800">Venue: </span>
                {event.venue}
              </div>
            </div>
          )}

          {/* Amount Box */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#0f4c81] to-[#155e9e] text-white rounded-xl">
            <div>
              <span className="text-xs text-sky-200">Total Booking Amount</span>
              <p className="text-2xl font-black">₹ {event.amount ? Number(event.amount).toLocaleString('en-IN') : '0'}</p>
            </div>
            <div className="text-xs text-sky-100 text-right">
              <span>HI-TECH SFX</span><br />
              <span className="opacity-75">All Taxes Included</span>
            </div>
          </div>

          {/* Notes */}
          {event.notes && (
            <div className="border border-slate-200 rounded-xl p-3 bg-white">
              <span className="text-xs font-bold text-slate-600 block mb-1">Equipment & Crew Notes:</span>
              <p className="text-xs text-slate-700 whitespace-pre-line leading-relaxed">{event.notes}</p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-2 justify-end">
          <button
            onClick={handleWhatsAppShare}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Send on WhatsApp</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-900 transition cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Slip</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-300 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
