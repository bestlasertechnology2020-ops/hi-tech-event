import React, { useState } from 'react';
import { 
  generateAndroidProjectZip, 
  MAIN_ACTIVITY_JAVA, 
  ANDROID_MANIFEST_XML, 
  APP_BUILD_GRADLE, 
  GITHUB_ACTIONS_WORKFLOW,
  ROOT_BUILD_GRADLE,
  SETTINGS_GRADLE
} from '../services/apkProjectGenerator';
import { 
  Download, 
  FileCode, 
  Check, 
  Copy, 
  ExternalLink, 
  Layers, 
  Cpu, 
  Smartphone, 
  Github, 
  Terminal, 
  ShieldCheck, 
  FileCheck,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ApkBuilderGuide: React.FC = () => {
  const [downloading, setDownloading] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'java' | 'manifest' | 'gradle' | 'workflow' | 'settings'>('java');
  const [copiedTab, setCopiedTab] = useState<string | null>(null);

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      const blob = await generateAndroidProjectZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HiTechSFX_EventManager_Android_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (err) {
      console.error('Failed to generate project zip', err);
    } finally {
      setDownloading(false);
    }
  };

  const copyToClipboard = (text: string, tabKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(tabKey);
    setTimeout(() => {
      setCopiedTab(prev => prev === tabKey ? null : prev);
    }, 2000);
  };

  const getCodeForTab = () => {
    switch (activeCodeTab) {
      case 'java':
        return { filename: 'app/src/main/java/.../MainActivity.java', code: MAIN_ACTIVITY_JAVA, lang: 'java' };
      case 'manifest':
        return { filename: 'app/src/main/AndroidManifest.xml', code: ANDROID_MANIFEST_XML, lang: 'xml' };
      case 'gradle':
        return { filename: 'app/build.gradle', code: APP_BUILD_GRADLE, lang: 'groovy' };
      case 'workflow':
        return { filename: '.github/workflows/build-apk.yml', code: GITHUB_ACTIONS_WORKFLOW, lang: 'yaml' };
      case 'settings':
        return { filename: 'settings.gradle', code: SETTINGS_GRADLE, lang: 'groovy' };
    }
  };

  const currentFile = getCodeForTab();

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      {/* Top Banner / Hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0f4c81] via-[#123e6b] to-[#0a233d] p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-400/20 text-sky-200 text-xs font-semibold border border-sky-400/30">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Android APK Generator Kit</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Build & Download Your APK
            </h2>
            <p className="text-sm text-sky-100/90 leading-relaxed">
              We have converted your <code className="bg-white/10 px-1.5 py-0.5 rounded text-amber-300 font-mono text-xs">MainActivity.java</code> into a full, production-ready Android Studio Project with SQLite database, Gradle scripts, and automated GitHub Actions CI.
            </p>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={downloading}
            className="shrink-0 flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-400/30 transition active:scale-95 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-5 h-5 text-slate-950" />
            <span>{downloading ? 'Bundling ZIP...' : 'Download Android Project (.ZIP)'}</span>
          </button>
        </div>

        {/* Decorative corner accent */}
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none translate-x-12 translate-y-12">
          <Smartphone className="w-80 h-80" />
        </div>
      </div>

      {/* 3 Clear Ways to Generate the APK */}
      <div className="space-y-4">
        <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-[#0f4c81]" />
          <span>3 Ways to Get the APK on Your Android Phone</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Method 1: Instant WebAPK PWA */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-sm mb-3">
                1
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">
                WebAPK (No PC Needed)
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Open this app in Chrome on your Android phone and tap <strong>&quot;Install Android App&quot;</strong>. Android automatically compiles a native <strong>WebAPK</strong> and puts an app icon on your home screen and launcher.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100">
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                <Check className="w-3 h-3" /> Ready Right Now
              </span>
            </div>
          </div>

          {/* Method 2: GitHub Actions Cloud Build */}
          <div className="bg-white rounded-2xl p-5 border-2 border-sky-500/40 shadow-sm hover:shadow-md transition flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-2 right-2 bg-sky-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
              Free Cloud Build
            </div>
            <div>
              <div className="w-10 h-10 rounded-xl bg-sky-100 text-[#0f4c81] flex items-center justify-center font-bold text-sm mb-3">
                2
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">
                GitHub Actions (2 Mins)
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Upload the downloaded ZIP to a free GitHub repository. Our included <code className="text-xs bg-slate-100 px-1 py-0.5 rounded text-sky-700">build-apk.yml</code> workflow triggers automatically on GitHub servers and produces a downloadable <code className="text-xs bg-slate-100 px-1 py-0.5 rounded text-sky-700">app-debug.apk</code> in 2 minutes!
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded-md">
                <Github className="w-3 h-3" /> 100% Free
              </span>
              <a 
                href="https://github.com/new" 
                target="_blank" 
                rel="noreferrer"
                className="text-[11px] font-bold text-[#0f4c81] hover:underline flex items-center gap-1"
              >
                New Repo <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Method 3: Android Studio */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-sm mb-3">
                3
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">
                Android Studio Local
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Extract the ZIP, open it in <strong>Android Studio</strong>, and click <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>. The APK will be ready at <code className="text-xs bg-slate-100 px-1 py-0.5 rounded text-purple-700">app/build/outputs/apk/debug/app-debug.apk</code>.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100">
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-800 bg-purple-50 px-2.5 py-1 rounded-md">
                <Terminal className="w-3 h-3" /> Standard SDK
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Complete Project Files Explorer */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0f4c81] flex items-center justify-center">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 text-base">
                Project Files & Source Inspector
              </h4>
              <p className="text-xs text-slate-500">
                All files included in the generated Android Studio Project ZIP
              </p>
            </div>
          </div>

          {/* Copy Button */}
          <button
            onClick={() => copyToClipboard(currentFile.code, activeCodeTab)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
          >
            {copiedTab === activeCodeTab ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-emerald-700">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy File Content</span>
              </>
            )}
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-50 px-4 pt-2 border-b border-slate-200 flex flex-wrap gap-1">
          <button
            onClick={() => setActiveCodeTab('java')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition border-t-2 ${
              activeCodeTab === 'java'
                ? 'bg-white text-[#0f4c81] border-[#0f4c81] shadow-xs'
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            MainActivity.java
          </button>
          <button
            onClick={() => setActiveCodeTab('manifest')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition border-t-2 ${
              activeCodeTab === 'manifest'
                ? 'bg-white text-[#0f4c81] border-[#0f4c81] shadow-xs'
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            AndroidManifest.xml
          </button>
          <button
            onClick={() => setActiveCodeTab('gradle')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition border-t-2 ${
              activeCodeTab === 'gradle'
                ? 'bg-white text-[#0f4c81] border-[#0f4c81] shadow-xs'
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            app/build.gradle
          </button>
          <button
            onClick={() => setActiveCodeTab('workflow')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition border-t-2 ${
              activeCodeTab === 'workflow'
                ? 'bg-white text-[#0f4c81] border-[#0f4c81] shadow-xs'
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            build-apk.yml (GitHub Actions)
          </button>
          <button
            onClick={() => setActiveCodeTab('settings')}
            className={`px-3 py-2 text-xs font-bold rounded-t-lg transition border-t-2 ${
              activeCodeTab === 'settings'
                ? 'bg-white text-[#0f4c81] border-[#0f4c81] shadow-xs'
                : 'text-slate-600 border-transparent hover:text-slate-900'
            }`}
          >
            settings.gradle
          </button>
        </div>

        {/* Code Viewer */}
        <div className="p-4 bg-slate-950 text-slate-100 font-mono text-xs overflow-x-auto max-h-[460px]">
          <div className="text-[11px] text-slate-400 pb-2 border-b border-slate-800 mb-2 flex justify-between">
            <span>Path: {currentFile.filename}</span>
            <span>Lines: {currentFile.code.trim().split('\n').length}</span>
          </div>
          <pre className="leading-relaxed whitespace-pre font-mono text-[11px]">
            {currentFile.code}
          </pre>
        </div>
      </div>

      {/* Step-by-Step GitHub Cloud Build Walkthrough */}
      <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-6 sm:p-7 space-y-4">
        <h4 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
          <Github className="w-5 h-5 text-slate-800" />
          <span>Walkthrough: Build Your APK on GitHub in 4 Clicks (Zero Setup)</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs text-slate-700">
          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
            <span className="font-black text-[#0f4c81] text-sm block">Step 1</span>
            <strong>Download the ZIP</strong>
            <p className="text-slate-500">Click the yellow &quot;Download Android Project (.ZIP)&quot; button above and extract it.</p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
            <span className="font-black text-[#0f4c81] text-sm block">Step 2</span>
            <strong>Upload to GitHub</strong>
            <p className="text-slate-500">Create a repository on GitHub (Public or Private) and drag all files to upload them.</p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
            <span className="font-black text-[#0f4c81] text-sm block">Step 3</span>
            <strong>Automatic Build</strong>
            <p className="text-slate-500">Go to the &quot;Actions&quot; tab on GitHub. The APK build workflow starts automatically!</p>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
            <span className="font-black text-[#0f4c81] text-sm block">Step 4</span>
            <strong>Download APK</strong>
            <p className="text-slate-500">Under Artifacts, download &quot;HiTechSFX-Event-Manager-Debug-APK&quot;. Tap on Android to install!</p>
          </div>
        </div>
      </div>
    </div>
  );
};
