export type EventStatus = 
  | 'Booked' 
  | 'Advance Pending' 
  | 'Confirmed' 
  | 'Completed' 
  | 'Cancelled';

export interface SFXEvent {
  id: number;
  customer: string;
  type: string;
  event_date: string; // YYYY-MM-DD
  venue: string;
  phone: string;
  amount: string;
  status: EventStatus;
  notes: string;
  created_at?: string;
}

export type ViewTab = 'simulator' | 'apk-builder' | 'calendar' | 'project-files';
