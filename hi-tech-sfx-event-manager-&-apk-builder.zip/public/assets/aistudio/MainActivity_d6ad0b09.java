package com.hitech.sfx.eventmanager;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    DB helper;
    LinearLayout root, form, list;
    EditText customer, type, venue, phone, amount, notes, search;
    TextView dateText, summary;
    Spinner status;
    Button saveButton;
    long editingId = -1;
    String selectedDate = "";
    final String[] statuses = {"Booked", "Advance Pending", "Confirmed", "Completed", "Cancelled"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        helper = new DB(this);
        buildUI();
        refreshList("");
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(30, 41, 59));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    EditText field(String hint, int inputType) {
        EditText e = new EditText(this); e.setSingleLine(inputType != 0);
        e.setHint(hint); e.setTextSize(15); e.setInputType(inputType);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(148,163,184)));
        return e;
    }
    LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(10), dp(16), dp(10)); return l;
    }
    void addField(LinearLayout parent, String label, View v) {
        parent.addView(text(label, 13, true));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8); parent.addView(v, p);
    }
    Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); return b;
    }

    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = vertical(); root.setBackgroundColor(Color.rgb(245,247,251));
        scroll.addView(root); setContentView(scroll);
        TextView title = text("HI-TECH SFX", 25, true);
        title.setTextColor(Color.rgb(15, 76, 129)); root.addView(title);
        root.addView(text("Event Date & Data Manager", 17, true));
        root.addView(text("Offline event records • Stored on this phone", 12, false));
        root.addView(space(8));

        form = vertical(); form.setBackgroundColor(Color.WHITE);
        root.addView(form);
        form.addView(text("Add / Edit Event", 18, true));
        customer = field("Customer / company name", 1);
        type = field("Event type (wedding, corporate, etc.)", 1);
        venue = field("Venue / address", 1);
        phone = field("Contact number", 3);
        amount = field("Total amount (₹)", 8194);
        notes = field("Notes, equipment, crew or payment details", 0);
        notes.setMinLines(2); notes.setGravity(Gravity.TOP);
        dateText = text("Choose event date  ▾", 16, true);
        dateText.setPadding(dp(12), dp(14), dp(12), dp(14));
        dateText.setBackgroundColor(Color.rgb(232,240,250));
        dateText.setOnClickListener(v -> chooseDate());
        status = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, statuses);
        status.setAdapter(adapter);
        addField(form, "Customer", customer);
        addField(form, "Event type", type);
        addField(form, "Event date", dateText);
        addField(form, "Venue", venue);
        addField(form, "Phone", phone);
        addField(form, "Amount", amount);
        addField(form, "Status", status);
        addField(form, "Notes", notes);
        saveButton = button("Save Event");
        saveButton.setTextColor(Color.WHITE); saveButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(15,76,129)));
        form.addView(saveButton);
        Button clear = button("Clear Form");
        form.addView(clear);
        saveButton.setOnClickListener(v -> saveEvent());
        clear.setOnClickListener(v -> clearForm());

        root.addView(space(12));
        summary = text("Events", 18, true); root.addView(summary);
        search = field("Search customer, event, venue, phone...", 1);
        root.addView(search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ refreshList(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
        list = vertical(); root.addView(list);
        root.addView(text("Tip: tap an event to edit it. Long-press an event to delete it.", 12, false));
    }
    View space(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }

    void chooseDate() {
        Calendar c = Calendar.getInstance();
        if (!selectedDate.isEmpty()) {
            try { c.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(selectedDate)); } catch(Exception ignored){}
        }
        new DatePickerDialog(this, (view,y,m,d) -> {
            selectedDate = String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);
            dateText.setText("Event date: " + selectedDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }
    void saveEvent() {
        String name = customer.getText().toString().trim();
        if (name.isEmpty()) { customer.setError("Customer name is required"); return; }
        if (selectedDate.isEmpty()) { Toast.makeText(this,"Please choose an event date",Toast.LENGTH_SHORT).show(); return; }
        ContentValues v = new ContentValues();
        v.put("customer", name); v.put("type", type.getText().toString().trim());
        v.put("event_date", selectedDate); v.put("venue", venue.getText().toString().trim());
        v.put("phone", phone.getText().toString().trim()); v.put("amount", amount.getText().toString().trim());
        v.put("status", statuses[status.getSelectedItemPosition()]); v.put("notes", notes.getText().toString().trim());
        SQLiteDatabase db = helper.getWritableDatabase();
        if (editingId == -1) db.insert("events", null, v); else db.update("events", v, "_id=?", new String[]{String.valueOf(editingId)});
        Toast.makeText(this, editingId == -1 ? "Event saved" : "Event updated", Toast.LENGTH_SHORT).show();
        clearForm(); refreshList(search == null ? "" : search.getText().toString());
    }
    void clearForm() {
        editingId = -1; customer.setText(""); type.setText(""); venue.setText(""); phone.setText("");
        amount.setText(""); notes.setText(""); status.setSelection(0); selectedDate = "";
        dateText.setText("Choose event date  ▾"); saveButton.setText("Save Event");
    }
    void refreshList(String query) {
        if (list == null || helper == null) return;
        list.removeAllViews();
        SQLiteDatabase db = helper.getReadableDatabase();
        String q = "%" + query + "%";
        Cursor c = db.rawQuery("SELECT _id,customer,type,event_date,venue,phone,amount,status,notes FROM events WHERE customer LIKE ? OR type LIKE ? OR venue LIKE ? OR phone LIKE ? OR event_date LIKE ? ORDER BY event_date ASC",
                new String[]{q,q,q,q,q});
        int count = c.getCount();
        summary.setText("Events (" + count + ")");
        if (count == 0) list.addView(text("No events yet. Add your first event above.", 14, false));
        while (c.moveToNext()) {
            long id=c.getLong(0);
            String name=c.getString(1), evType=c.getString(2), date=c.getString(3), loc=c.getString(4), ph=c.getString(5), amt=c.getString(6), st=c.getString(7), nt=c.getString(8);
            LinearLayout card = vertical(); card.setBackgroundColor(Color.WHITE);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(8); list.addView(card,cp);
            TextView heading=text(name,17,true); heading.setTextColor(Color.rgb(15,76,129)); card.addView(heading);
            card.addView(text(date + "   •   " + (evType.isEmpty()?"Event":evType),14,true));
            if (!loc.isEmpty()) card.addView(text("Venue: "+loc,13,false));
            if (!ph.isEmpty()) card.addView(text("Phone: "+ph,13,false));
            if (!amt.isEmpty()) card.addView(text("Amount: ₹"+amt,13,false));
            card.addView(text("Status: "+st,13,true));
            if (!nt.isEmpty()) card.addView(text("Notes: "+nt,13,false));
            card.setOnClickListener(view -> {
                editingId=id; customer.setText(name); type.setText(evType); selectedDate=date;
                dateText.setText("Event date: "+date); venue.setText(loc); phone.setText(ph); amount.setText(amt); notes.setText(nt);
                int ix=0; for(int i=0;i<statuses.length;i++) if(statuses[i].equals(st)) ix=i; status.setSelection(ix);
                saveButton.setText("Update Event");
                Toast.makeText(this,"Event loaded for editing",Toast.LENGTH_SHORT).show();
            });
            card.setOnLongClickListener(view -> {
                new AlertDialog.Builder(this).setTitle("Delete event?")
                    .setMessage("Delete event for "+name+" on "+date+"? This cannot be undone.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
                        helper.getWritableDatabase().delete("events","_id=?",new String[]{String.valueOf(id)});
                        refreshList(search.getText().toString());
                    }).show(); return true;
            });
        }
        c.close();
    }

    static class DB extends SQLiteOpenHelper {
        DB(Activity a) { super(a,"hitech_events.db",null,1); }
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE events (_id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL, type TEXT, event_date TEXT NOT NULL, venue TEXT, phone TEXT, amount TEXT, status TEXT, notes TEXT)");
            db.execSQL("CREATE INDEX idx_events_date ON events(event_date)");
        }
        public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {}
    }
}
